$(() => {
  $('#scheduler').dxScheduler({
    timeZone: 'America/Los_Angeles',
    dataSource: data,
    showAllDayPanel: false,
    //views: ['timelineDay', 'timelineWeek', 'month'],
    views: [
        {
            type: "timelineDay",
            name: "Day",
            startDayHour: 0,
            endDayHour: 24,
            cellDuration: 60
        },
        {
            type: "timelineWeek",
            name: "Week",
            cellDuration: 1440, 
            firstDayOfWeek: 1,
            cellDurationUnit: "minute",
            rowHeight: 100
        },
        {
            type: "month",
            name: "Month",
            startDayHour: 0,
            firstDayOfWeek: 1,
            endDayHour: 24,
            onCellPrepared: function(args) {
                if (args.cellType === "data" && (args.date.getDay() === 0 || args.date.getDay() === 6)) {
                    args.cellElement.css("background-color", "red"); // set the background color for weekend days
                }
            }
        }
    ],
    currentView: 'timelineWeek',
    currentDate: new Date(),
    startDayHour: 9,
    height: 750,
     editing: true,
    groups: ["priority"],
        resources: [{
            fieldExpr: "typeId",
            allowMultiple: false,
            dataSource: resourcesData,
            label: "Working From"
        } ],
  });
});