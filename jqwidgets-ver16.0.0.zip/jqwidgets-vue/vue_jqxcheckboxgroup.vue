<template>
    <div v-bind:id="id">
        <slot></slot>
    </div>
</template>

<script>
    import '../jqwidgets/jqxcore.js';

    export default {
        props: {
            change: Boolean,
            disabled: Boolean,
            items: [],
            value: [],
            layout: String,
            labelPosition: String,
            rtl: Boolean,
            theme: String,
            autoCreate: {
                default: true,
                type: Boolean
            }
        },
        created: function () {
            this.id = 'jqxCheckBoxGroup' + JQXLite.generateID();
            this.componentSelector = '#' + this.id;
        },
        mounted: function () {
            if (this.autoCreate) this.__createComponent__();
        },
        methods: {
            createComponent: function (options) {
                if (!this.autoCreate) this.__createComponent__(options)
                else console.warn('Component is already created! If you want to use createComponent, please set "autoCreate" property to "false".');
            },
            setOptions: function (options) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup(options);
            },
            getOptions: function () {
                const usedProps = Object.keys(this.__manageProps__());
                const resultToReturn = {};
                for (let i = 0; i < usedProps.length; i++) {
                    resultToReturn[usedProps[i]] = JQXLite(this.componentSelector).jqxCheckBoxGroup(usedProps[i]);
                }
                return resultToReturn;
            },
            getValue: function() {
                return JQXLite(this.componentSelector).jqxCheckBoxGroup('getValue');  
            },
            getValueAt: function(index) {
                return JQXLite(this.componentSelector).jqxCheckBoxGroup('getValueAt', index);  
            },
            enableAt: function(index) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('enableAt', index);  
            },
            disableAt: function(index) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('disableAt', index);  
            },
            checkAt: function(index) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('checkAt', index);  
            },
            uncheckAt: function(index) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('uncheckAt', index);  
            },
            uncheckAll: function() {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('uncheckAll');  
            },
            checkAll: function() {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('checkAll');  
            },
            checkValue: function(value) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('checkValue', value);  
            },
            uncheckValue: function(value) {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('uncheckValue', value);  
            },
            disable: function() {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('disable');  
            },
            destroy: function() {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('destroy');  
            },
            enable: function() {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('enable');  
            },
            render: function() {
                JQXLite(this.componentSelector).jqxCheckBoxGroup('render');  
            },
            val: function(value) {
                if (value !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('val',  value)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('val');
                }
            },
            _change: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('change', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('change');
                }
            },
            _disabled: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('disabled', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('disabled');
                }
            },
            _items: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('items', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('items');
                }
            },
            _value: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('value', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('value');
                }
            },
            _layout: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('layout', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('layout');
                }
            },
            _labelPosition: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('labelPosition', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('labelPosition');
                }
            },
            _rtl: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('rtl', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('rtl');
                }
            },
            _theme: function(arg) {
                if (arg !== undefined) {
                    JQXLite(this.componentSelector).jqxCheckBoxGroup('theme', arg)
                } else {
                    return JQXLite(this.componentSelector).jqxCheckBoxGroup('theme');
                }
            },
            __createComponent__: function (options) {
                let widgetOptions;
                options ? widgetOptions = options : widgetOptions = this.__manageProps__();
                JQXLite(this.componentSelector).jqxCheckBoxGroup(widgetOptions);
                this.__extendProps__();
                this.__wireEvents__();
            },
            __manageProps__: function () {
                const widgetProps = ['change','disabled','items','value','layout','labelPosition','rtl','theme'];
                const componentProps = this.$options.propsData;
                let options = {};

                for (let prop in componentProps) {
                    if (widgetProps.indexOf(prop) !== -1) {
                        options[prop] = componentProps[prop];
                    }
                }
                return options;
            },
            __extendProps__: function () {
                const that = this;

                Object.defineProperty(that, 'change', {
                    get: function() {
                        return that._change();
                    },
                    set: function(newValue) {
                        that._change(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'disabled', {
                    get: function() {
                        return that._disabled();
                    },
                    set: function(newValue) {
                        that._disabled(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'items', {
                    get: function() {
                        return that._items();
                    },
                    set: function(newValue) {
                        that._items(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'value', {
                    get: function() {
                        return that._value();
                    },
                    set: function(newValue) {
                        that._value(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'layout', {
                    get: function() {
                        return that._layout();
                    },
                    set: function(newValue) {
                        that._layout(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'labelPosition', {
                    get: function() {
                        return that._labelPosition();
                    },
                    set: function(newValue) {
                        that._labelPosition(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'rtl', {
                    get: function() {
                        return that._rtl();
                    },
                    set: function(newValue) {
                        that._rtl(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(that, 'theme', {
                    get: function() {
                        return that._theme();
                    },
                    set: function(newValue) {
                        that._theme(newValue);
                    },
                    enumerable: true,
                    configurable: true
                });
            },
            __wireEvents__: function () {
                const that = this;

            }
        }
    }
</script>
